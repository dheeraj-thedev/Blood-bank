# Blood Bank Management System-Undergrad Final Year Project
#Objective
 To provide all the information about awareness of blood and blood donation camps 

and manages all that information related with the event.

 Create blood donation events and aware people and users of website by notification  

through mails and bulletin board

 Gather and manage details about each donor in event and manage these information in 

database.

 Make blood tests in laboratory and gather all the information about tests, methods and 

results of tests into database and generate blood reports for each donor.

 Manage detailed information about staff members into database.

 Generate Event Statistics and summary reports and annual reports of blood bank.

 Manage blood bank inventory.

#Technology Used
J2EE, JSP, Servlets, Hibernet, Struts, MySQL.
